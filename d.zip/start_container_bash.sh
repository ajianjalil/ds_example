#!/bin/bash
docker-compose run --entrypoint bash aivs_service_triton_70
